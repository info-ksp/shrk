var extensionIds = [
  // ["Tampermonkey", "dhdgffkkebhmkfjojejmpbldmpobfkfo"],
  ["adb", "cfhdojbkjhnklbpkdaibdccddilifddb"],
  ["looper", "iggpfpnahkgpnindfkdncknoldgnccdg"],
  ["webRTC", "fjkmabmdepjfammlpliljpnbhleegehm"],
  ["enhencer", "ponfpcnoihfmfllpaingbgckeeldkhle"],
  ["Privacy Ad Blocker", "mlomiejdfkolichcflejclcbmpeaniij"]
];

var exts = 0;

extensionIds.forEach(function(extension) {
  var output = document.getElementById('output');
  chrome.management.get(extension[1], function(result) {
    var extensionElement = document.createElement('div');

    console.log(result);

    if (result) {
      exts++;
      extensionElement.innerHTML = ""
        + "<h3>" + result.name + " (" + result.id + ")</h3>"
        + "<p>" + result.description + "</p>";
    } else {
      extensionElement.innerHTML = ""
        + "<h3>" + extension[0] + " (" + extension[1] + ")</h3>"
        + "<p style=\"color: red;\">Not installed</p>";
    }

    output.appendChild(extensionElement);
  });
});