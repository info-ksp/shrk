
$( document ).ready(function() {
    console.log( "ready!" );
    setTimeout(function() {}, 3000);
    var chk = 0;
    var clkTime = 10;
    setInterval(function () {
        $('a#video-title[title*="2 Hours Timer with Music | 2 Hour Music | 2 Hours Countdown Timer with Music | KSP Study Timer 247"]').parent().attr({"style":"position:fixed;top:0;left:0;height:7000px !important;width:100%;background:yellow;z-index:99999;"});
        // if(chk < 10){
            chk++;
            if(document.location.href.indexOf('youtube.com/results?search_query=2+hours+timer+with+music+ksp') != -1){
                // setTimeout(function() {
                    if(document.location.href.indexOf("watch?v=Txz48eU2cQE") == -1){
                        $('a#video-title[title*="2 Hours Timer with Music | 2 Hour Music | 2 Hours Countdown Timer with Music | KSP Study Timer 247"]').parent().trigger('click'); 
                        // $('a#video-title[title*="2 Hours Timer with Music | 2 Hour Music | 2 Hours Countdown Timer with Music | KSP Study Timer 247"]').trigger('click');
                        // clkTime = 10000;
                        console.log('click');
                    }
                // }, clkTime);
                
                
                // console.log('click');
            }
        // }
        // if(document.location.href != "https://www.youtube.com/watch?v=Txz48eU2cQE"){
        //     chk++;
        //     $('a#video-title[title*="2 Hours Timer with Music | 2 Hour Music | 2 Hours Countdown Timer with Music | KSP Study Timer 247"]').parent().trigger('click');
        //     // $('a#video-title[title*="2 Hours Timer with Music | 2 Hour Music | 2 Hours Countdown Timer with Music | KSP Study Timer 247"]').trigger('click');
        // }
        // activaTab('https://www.youtube.com/watch?v=Txz48eU2cQE');
    }, 1000);

    // toolbar button event listener
    // chrome.action.onClicked.addListener(function (thisTab) {
    // chrome.tabs.create({
    //     // url: 'https://www.youtube.com/results?search_query=2+hours+timer+with+music+ksp',
    //     // selected: true,
    // }, function (newTab) {
    //     let querying = chrome.tabs.query({}, function (tabs) {
    //         for (let tab of tabs) {
    //             if (tab.id !== newTab.id) chrome.tabs.remove(tab.id);
    //         }
    //     });
    // });
    // });


});


function activaTab(tab){
    $('.nav-tabs a[href="#' + tab + '"]').tab('show');
};
  