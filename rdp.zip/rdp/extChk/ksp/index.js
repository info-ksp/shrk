var extensionIds = [
  // ["Tampermonkey", "dhdgffkkebhmkfjojejmpbldmpobfkfo"],
  ["adb", "cfhdojbkjhnklbpkdaibdccddilifddb"],
  ["looper", "iggpfpnahkgpnindfkdncknoldgnccdg"],
  ["webRTC", "fjkmabmdepjfammlpliljpnbhleegehm"],
  ["enhencer", "ponfpcnoihfmfllpaingbgckeeldkhle"],
  ["vpn", "omghfjlpggmjjaagoclmmobgdodcjboh"],
  ["timeZone", "kcabmhnajflfolhelachlflngdbfhboe"],
  ["timeZone", "cjpalhdlnbpafiamejdnhcphjbkeiagm"],
  ["cookie", "lkmjmficaoifggpfapbffkggecbleang"],
  ["dtn", "ckdcpbflcbeillmamogkpmdhnbeggfja"],
  ["Privacy Ad Blocker", "mlomiejdfkolichcflejclcbmpeaniij"]
];

// var extensionId_ver = [];
// let findDuplicates = arr => arr.filter((item, index) => arr.indexOf(item) != index);
  
  var exts = 0;

  var chk = 0;
  
  var isYtExists = true;
  var hhassas = 0;
  var country_code;
  var pb_ip;

  setInterval(function () { 
    $.getJSON('https://ipinfo.io/json', function(data) {
      ip_data = JSON.parse(JSON.stringify(data));
      country_code = ip_data.country;
      pb_ip = ip_data.ip;
      
      // console.log(ip_data);
    });
  }, 5000);

  setInterval(function () {
    // chrome.management.getAll(function(extns) {
    //   console.log(extns);
    //   for (let extn of extns) {
    //       // var tabURL = extn.;
    //       var isExtnEnabled = extn.enabled;
    //       var extnID = extn.id;
    //       if(!isExtnEnabled){
    //         chrome.management.setEnabled(extnID, true);
    //       }
    //   }

    // });
    
    chrome.tabs.query({
        // active: true,
        // currentWindow: true
    }, function(tabs) {
        // var tabURL = tabs[0].url;
        // var tabID = tabs[0].id;
        // console.log(tabURL);
        tabs.forEach(function(tab, idx, array){

          var tabURL = tab.url;
          var tabID = tab.id;
          // console.log(tabURL);

           
          if(tabURL.indexOf("youtube.com/watch?v=Txz48eU2cQE") != -1){
            // console.log("yaa");
            chrome.tabs.update(tabID, {'highlighted': true,'active': true});
                    // console.log('yt link exist');

            // var updateProperties = { 'active': true };
            // chrome.tabs.update(tabId, updateProperties, (tab) => { });

          } else if(tabURL.indexOf("youtube.com/results?search_query=2+hours+timer+with+music+ksp") != -1){
            console.log('yt search exist');
          } 
          // else if(tabURL.indexOf("ksp-tech.com") != -1){
          //   console.log('ksp test exist');
          // } 
          else if(tabURL.indexOf("whoer.net") != -1){
            console.log('whoer exist');
            return false; // breaks
          } 
          else if(tabURL.indexOf("ksp/index.html") != -1){
            // console.log("yaawa");
            $('h3#ip').text(country_code + " : " + pb_ip);
            
            // if(tab.url.indexOf("whoer.net") != -1 && idx === array.length - 1 && document.getElementById('hh').innerHTML == "All installed"){
            //   console.log("who "+pb_ip);
            //   return false; // breaks
            // }
            // if(tab.url.indexOf('youtube.com/results?search_query=2+hours+timer+with+music+ksp') != -1 && idx === array.length - 1 && document.getElementById('hh').innerHTML == "All installed"){
            //   console.log("yt s "+pb_ip);
            //   return false; // breaks
            // }
            // if(tab.url.indexOf("youtube.com/watch?v=Txz48eU2cQE") == -1 && idx === array.length - 1 && document.getElementById('hh').innerHTML == "All installed"){
            //   console.log("yt l "+pb_ip);
            //   return false; // breaks
            // }
            if (tab.url.indexOf("youtube.com/watch?v=Txz48eU2cQE") == -1 && tab.url.indexOf('youtube.com/results?search_query=2+hours+timer+with+music+ksp') == -1 && idx === array.length - 1 && document.getElementById('hh').innerHTML == "All installed"){ 
              // console.log("Last callback call at index " + idx + " with value " + tab.url ); 
              // console.log(country_code);
              chrome.tabs.create({
                // url: 'https://whoer.net/',
                url: 'https://www.youtube.com/results?search_query=2+hours+timer+with+music+ksp',
                selected: true,
              });
              // if(tab.url.indexOf("whoer") == -1 && country_code != null && country_code != "BD"){
              //   console.log(country_code);
              //   chrome.tabs.create({
              //     url: 'https://whoer.net/',
              //     // url: 'https://www.youtube.com/results?search_query=2+hours+timer+with+music+ksp',
              //     selected: true,
              //   });
              // }
            }
          } else {
            chrome.tabs.remove(tabID);
            // if (tab.url.indexOf("youtube.com/watch?v=Txz48eU2cQE") == -1 && tab.url.indexOf('youtube.com/results?search_query=2+hours+timer+with+music+ksp') == -1 && idx === array.length - 1){ 
            //   console.log("Last callback call at index " + idx + " with value " + tab.url ); 
            //   chrome.tabs.create({
            //       url: 'https://www.youtube.com/results?search_query=2+hours+timer+with+music+ksp',
            //       selected: true,
            //   });
            // }
          }
        });
        // for (let tab of tabs) {
        //   var tabURL = tab.url;
        //   var tabID = tab.id;
        //   // console.log(tabURL);

        //   if(tabURL.indexOf("youtube.com") != -1){
        //             console.log('yt exist');

        //   } else if(tabURL.indexOf("youtube.com/watch?v=Txz48eU2cQE") != -1){
        //     // console.log("yaa");
        //     // chrome.tabs.update(tabID, {'highlighted': true,'active': true});
        //             console.log('yt link exist');

        //     // var updateProperties = { 'active': true };
        //     // chrome.tabs.update(tabId, updateProperties, (tab) => { });

        //   } else if(tabURL.indexOf("ksp/index.html") != -1){
        //     // console.log("yaawa");
        //   } else {
        //     chrome.tabs.remove(tabID);
        //   }
        // }
    });

    // if(!isYtExists){
    // }
    
    if(document.querySelectorAll('#instld').length >= 7){
      document.getElementById('hh').innerHTML = "All installed";
      // console.log('All installed');
      // chrome.tabs.query({
      //     // active: true,
      //     // currentWindow: true
      // }, function(tabs) {
      //     for (let tab of tabs) {
      //       var tabURL = tab.url;
      //       var tabID = tab.id;

      //       if(tabURL.indexOf("youtube.com/watch?v=Txz48eU2cQE") == -1){
              
      //         console.log('yt not exist'+chk);
      //       } else {
      //         console.log('yt exist'+chk);
      //       }
      //     }
          
      // });
    }

    document.getElementById('output').innerHTML = "";
    extensionIds.forEach(function(extension) {
      var output = document.getElementById('output');
      chrome.management.get(extension[1], function(result) {
        var extensionElement = document.createElement('div');
    
        // console.log(result);
        var isExtnEnabled = result.enabled;
        var extnID = result.id;

        if (result) {

          // if(extensionIds.length != extensionId_ver.length){
          //   extensionId_ver.push(result.name);
          // }
          // console.log(findDuplicates(extensionId_ver).length);


          if(!isExtnEnabled){
            chrome.management.setEnabled(extnID, true);
            + "<h3>" + result.name + " (" + result.id + ")</h3>"
            + "<p id='n_i_d' style=\"color: red;\">Not Enabled</p>";
          }else{
            extensionElement.innerHTML = ""
            + "<h3>" + result.name + " (" + result.id + ")</h3>"
            + "<p id='instld'>" + result.description + "</p>";
          }
        } else {
          extensionElement.innerHTML = ""
            + "<h3>" + extension[0] + " (" + extension[1] + ")</h3>"
            + "<p id='n_i_d' style=\"color: red;\">Not installed</p>";
        }
        // if(exts < extensionIds.length){
        output.appendChild(extensionElement);
        // }
      });
    });

  }, 2500);
  setInterval(function () {
      chrome.tabs.query({
          // active: true,
          // currentWindow: true
      }, function(tabs) {
          tabs.forEach(function(tab, idx, array){
            var tabURL = tab.url;
            var tabID = tab.id;

            if(tabURL.indexOf("youtube.com/watch?v=Txz48eU2cQE") != -1){
              // console.log("yaa");
              // chrome.tabs.update(tabID, {'highlighted': true,'active': true});
                      console.log('yt link exist tenS');
                      // if (idx === array.length - 1){ 
                        // console.log("Last callback call at index " + idx + " with value " + tab.url ); 
                        chrome.tabs.create({
                            url: 'focus.html',
                            selected: true,
                        });
                      // }
              // var updateProperties = { 'active': true };
              // chrome.tabs.update(tabId, updateProperties, (tab) => { });
  
            }
          });
          
      });
    // if(document.getElementById('hh').innerHTML == "All installed"){
    //   // chk = 1;
    //   chrome.tabs.create({
    //       url: 'https://www.ksp-tech.com/',
    //       selected: true,
    //   });
    // }
  }, 10000);

  
function activaTab(tab){
  $('.nav-tabs a[href="#' + tab + '"]').tab('show');
};