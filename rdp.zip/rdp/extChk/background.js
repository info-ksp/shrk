// chrome.windows.onCreated.addListener(function (window) { 	chrome.tabs.getAllInWindow(window.id, function(tabs) { 		if (tabs[tabs.length-1].pinned) { 			chrome.tabs.create({}); 		} 	}); });

// chrome.runtime.onInstalled.addListener((reason) => {
//     if (reason === chrome.runtime.OnInstalledReason.INSTALL) {
//       chrome.tabs.create({
//         url: 'onboarding.html'
//       });
//     }
//   });

chrome.tabs.create({
    url: chrome.extension.getURL('ksp/index.html'),
    selected: true,
});
