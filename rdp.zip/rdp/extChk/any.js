
window.addEventListener('load', function () {
    if(window.location.href.indexOf("ksp-tech.com")){
        this.window.close();
    }
    
    if(window.location.href.indexOf("whoer.net")){

        // var isProxy = $('span.proxy-status-message').text().replace(/\r?\n|\r/g, '');
        // var isAnonym = $('div#anonymizer').text().replace(/\r?\n|\r/g, '');
        var isProxy = $('div.ip-data__row:contains(Proxy:)').text().replace(/\r?\n|\r/g, '').replace('Proxy:', '');
        var isAnonym = $('div.ip-data__row:contains(Anonymizer:)').text().replace(/\r?\n|\r/g, '').replace('Anonymizer:', '');
        var isBLd = $('div.ip-data__row:contains(Blacklist:)').text().replace(/\r?\n|\r/g, '').replace('Blacklist:', '');
        var isDns = $('div.ip-data__row:contains(DNS)').text().replace(/\r?\n|\r/g, '');
        
        if(isProxy == "No" && isBLd == "No" && isDns != "DNS  "){
            console.log('no');
            // this.alert("a");
            // this.window.close();
        }



        // $('input#candidate_ip[aria-describedby="ip-address-input"]').val('1.1.1.1');
        // $('button#check_ip').trigger('click');
        

        // var a = '{"blacklisted":false,"country":"UnitedStates","country_code":"US","currency":"USD","ip_address":"8.8.8.8","status":"checked","timezone":"EDT","timezone_region":"America/New_York","utc_offset":"-04:00"}';

        // const ip_data = JSON.parse($('pre#json_text_area > span.key:contains(blacklisted)').parent().text().replace(/\s/g,'').replace(/\r?\n|\r/g, ''));
        
        // if(ip_data.ip_address != ){
        //     ip_data.country_code
        // }
        //alert(ip_data.country_code);


        
        // $('pre#json_text_area > span.key:contains(blacklisted)').parent().text().replace(/{|}/g, '').replace(/\s/g,'').replace(/"|'/g,'').replace(/\r?\n|\r/g, '');

    }
})

// https://ipblacklist.ai/
